<h2>Data Editor</h2>
<table class="table">
<thead>
<tr>
    <th>#</th>
    <th>Id Editor</th>
    <th>Nama Editor</th>
    <th>Action</th>
</tr>
</thead>
<tbody>
<?php foreach($editorabc as $editors): ?>
<tr>
    <td></td>
    <td>
    <?= $editors['id_editor'] ?>
    </td>
    <td>
    <?= $editors['nama_editor'] ?><br>
    </td>
    <td>
         <a href="<?= base_url('admin/news/'.$editors['id_editor'].'/edit') ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
        <a href="#" data-href="<?= base_url('admin/news/'.$editors['id_editor'].'/delete') ?>" onclick="confirmToDelete(this)" class="btn btn-sm btn-outline-danger">Delete</a>
    </td>
</tr>
<?php endforeach ?>
</tbody>
</table>




