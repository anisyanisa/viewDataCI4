<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\EditorModel;

class Editor extends BaseController
{
    public function index()
    {
        $editor = new EditorModel();
        $data['editorabc'] = $editor->findAll();
		return view('templates/header', ['title' => 'View a editors item'])
            . view('editors/editorlist',$data)
            . view('templates/footer');
    
    }
    public function new() //memanggil form tambah view/pages/createunit.php
    {
        //helper('form');

        return view('templates/header', ['title' => 'Create a Unit item'])
            . view('editors/createeditor')
            . view('templates/footer');
    }


    public function viewEditors($slug)
	{
		$editor = new EditorModel();
		$data['id_editor'] = $editor->findAll();

        // tampilkan 404 error jika data tidak ditemukan
		// if (!$data['news']) {
		// 	throw PageNotFoundException::forPageNotFound();
		// }

		echo view('news_detail', $data);
	}

    public function create() //untuk mneyimpan data ke db
    {
        helper('form');

        $data = $this->request->getPost(['id_editor', 'nama_editor']);

        // Checks whether the submitted data passed the validation rules.
        if (! $this->validateData($data, [
            'id_editor' => 'required|max_length[10]|min_length[3]',
            'nama_editor'  => 'required|max_length[25]|min_length[5]',
        ])) {
            // The validation fails, so returns the form.
            return $this->new();
        }

        // Gets the validated data.
        $post = $this->validator->getValidated();

        $model = model(EditorModel::class);

        $model->save([
            'id_editor' => $post['id_editor_text'],
            'nama_editor'  => $post['nama_editor_text'],
        ]);

        return view('templates/header', ['title' => 'Create a editors item'])
            . view('news/success')
            . view('templates/footer');
    }
    
}
