<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
// $routes->get('/pages', 'Pages::index');
// $routes->get('/about', 'About::index');


$routes->get('editors', 'Editor::index');
//$routes->get('/editors/(:any)', 'Editor::viewNews/$1'); // Add this line
// $routes->post('news', [News::class, 'create']); // Add this line
// $routes->get('news/(:segment)', [News::class, 'show']);
$routes->get('/(:any)', 'Pages::view/$1');